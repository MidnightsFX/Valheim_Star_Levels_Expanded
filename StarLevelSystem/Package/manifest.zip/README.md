# StarLevelSystem

![TitleHeader](https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/art/TitleHeader.png?raw=true)

Star Level Systems expands upon the Valheim star system and allows extensive customization.

Features:
- Expand Creature Star levels (as high as you want)
	- Sizing configuration for all creatures
- Customize Raids, complete control over creatures, activation mechanics etc
    - Raids will be tailed to each players progress and multiple raids can occur at the same time
- Multiple different scaling strategies
    - Scale levels by distance
    - Scale levels by zones
    - Scale levels by bosses killed
- Nemesis System (personal/group dungeon master)
    - Can modify the world around you to make things easier, harder or provide unique challenges/opportunities
- Fine grained control of all creature aspects
	- Health, damage, size, speed, attack speed, base and per level
	- Resistance or weakness to all elements
- Unique colorization for any creature
	- Per level colorization for any creature
	- Bulk color generators for defining whole ranges of color levels
- Unique Modifiers for all creatures, multiple different categories (Boss, Major, Minor)
	- Creatures names based on modifiers
	- Star Icons based on modifiers
	- Visual effects for modifiers
	- Per level, fine grained configuration and tuning of modifiers
- Scaling, fine-grained control and configuration of all creature drops
	- scale individual loot entries differently
	- modify chance drops based on level of the creature
	- Add, remove, change all drops
- Scaling of the world around you
	- level up the FISH!
	- level scaled BIRDS
	- level scaled TREES
- Configurable location, dungeon, terrain and ore resets to passively regenerate the world around you
    - Supports mod locations, resources, and pickables


Got a bug to report or just want to chat about the mod? Drop by the discord or github.

[![discord logo](https://i.imgur.com/uE6umQE.png)](https://discord.gg/Dmr9PQTy9m) [![github logo](https://i.imgur.com/lvbP5OF.png)](https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded)

Below are a few examples of what you might see, and what the mod can do.

![HeaderExample](https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/art/Header.png?raw=true)

## First-time setup
The first time you reach the main menu, a short setup opens and walks through level scaling, the star range and its spawn chances,
the distance rings, creature health and damage, modifiers, raids, the Nemesis system and Location Reset. You can save from any page, or click the X to skip it. Either way
it won't open again, in this or any other mod manager profile: whether you have seen it is kept once per user, in
`ModQuickConfig/FirstRun.cfg` next to your Valheim saves (`%USERPROFILE%\AppData\LocalLow\IronGate\Valheim` on Windows). Set
`FirstTimeSetup` to `ShowNextLaunch` in the BepInEx config to see it again, or to `Never` to keep it closed in that profile. The same
pages (without the welcome page) open from the Mod Config button on the main menu, or on the pause menu for hosts and admins.
Each page has a Reset page button that puts just that page back to the mod's defaults; like any other edit, nothing is
written until you Save.

Upgrading rather than installing fresh? The setup stays out of your way: a config file that already exists when this
version first runs means the mod has been configured already, so it is marked done without being shown.

Other mods that share the Mod Config button can have a welcome of their own. They open one at a time, in turn, rather than on top of each other.

## Features

### Levels, Levels and more Levels (LevelSettings.yaml)
So you want creatures to have more levels, but you don't want to die instantly to a level 100 boar when you start the game? 
Well have I got the config file for you.

Level settings allows configuration of creature levelup chance, creature stats, max level, increased level up chance based on
distance from the center- and respectively biome based configs for all of that.

Want some help calculating and building a level definition? Check out [this tool](https://sls-levelspreadtool.netlify.app/)

#### Biome Configuration
Lets take a look at some of the things you can do with this, and what better spot to start out than the default `All` biome
configuration (which applies to every creature by default).

Here is a section of the default example config, lets walk through what everything does.
```
 All:
    distanceScaleModifier: 1.5       # The influence of distance ring based scale increases (1.5 means 150% of the bonus value will be applied)
    spawnRateModifier: 1.5           # Spawn rate of every creature is 50% higher (1.5), which means every spawn has a 50% chance of being 2 creatures.
    creatureBaseValueModifiers:      # These values modify the base stats of every creature in this biome (eg, all creatures)
      BaseHealth: 1                  # The default health of all creatures is 100% (1), numbers below 1 reduce health, above increase is (2) is 200% health for everything
      BaseDamage: 1                  # Default damage of all creatures is 100% (1)
      Speed: 1                       # Default movement speed of all creatures is 100% (1)
      Size: 1                        # Default size of all creatures is 100% (1)
    creaturePerLevelValueModifiers:  # Per level modifiers are applied per level, eg each star will give this value to the creature
      HealthPerLevel: 0.4            # Each star provides 40% more health (0.4)
      DamagePerLevel: 0.1            # Each star provides 10% more damage (0.1)
      SpeedPerLevel: 0               # Each star does not increase speed (0)
      SizePerLevel: 0.1              # Each star makes the creature 10% bigger (0.1). Negative values shrink instead (-0.1 is 10% smaller per star)
    damageRecievedModifiers:         # Damage reduction or increases
      Poison: 1.5                    # Everything recieves 50% (1.5) more damage from poison (that includes players)
```
Note: `creaturePerLevelValueModifiers` do not apply to characters. But, `damageRecievedModifiers` DOES.

Note on sizing: per-level size is applied as `Size + (SizePerLevel * stars)`, so a 0 star creature is
exactly `Size`. `SizePerLevel` may be negative to make creatures shrink with each star. The final
multiplier is floored at the `MinimumCreatureScale` config value (default `0.1`), so creatures can never
reach zero size or turn inside-out no matter how negative the value is.

Biome specific configurations can be used to override the default `All` configuration, in this case max level for Ashlands is being set
to 26 and the distance modifier is being reduced by 50%
```
  AshLands:
    biomeMaxLevelOverride: 26
    distanceScaleModifier: 0.5
```

#### Creature Configuration
Creature specific configuration allows you to override what is set in the biome definition for a creature, which allows more
fine-grained control of how a specific creature should be modified.

Lets take a look at this creature definition
```
  Troll:                                # Creature prefab name, must match exactly, you can find this using VNEI, the wiki, or Jotunn prefab documentation
    customCreatureLevelUpChance:        # Sets the levelup chance for this specific creature, overrides the default values, can still be modified by distance bonuses
      1: 100                            # Gauranteed level 1
      2: 50                             # 50% chance to reach level 2
      3: 5                              # 5% chance to reach level 3
    creatureMaxLevelOverride: 11        # Overrides the max level for this creature (11 instead of biome default)
    creatureBaseValueModifiers:         # Overrides the base stat modifiers for this creature, values below 1 reduce stats, above 1 increase stats
      BaseHealth: 1.05                  # Base health is increased by 5%
      BaseDamage: 0.95                  # Base damage is reduced by 5%
      Speed: 1.05                       # Speed is increased by 5%
      Size: 1.05                        # Size is increased by 5%
      AttackSpeed: 1.05                 # Attack speed is increased by 5%
    creaturePerLevelValueModifiers:     # Per level stat modifiers for this creature, these are multiplied by the creatures level and applied to the total stat value
      HealthPerLevel: 0.3               # Each star provides 30% more health
      DamagePerLevel: 0.05              # Each star provides 5% more damage
      SizePerLevel: 0.005               # Each star provides 0.5% more size (use a negative value to shrink per star)
    requiredModifiers:                  # Modifiers that this creature will always spawn with, regardless of level, chance or modifier limit, but still count towards max modifier count
      Poison: Major                     # Trolls will always spawn with the Poison major modifier, Modifier names can be found in Modifiers.yaml, along with their categories
```

#### Levelup Chance
This is a definition of the chance that a creature has to level up at each point.

This works hand in hand with the distance scale modifier and `distanceLevelBonus`, distance level bonuses are applied if
the creature falls into a distance category with bonuses.
eg: 
```
distanceLevelBonus:
  1250:
    1: 25
```
Will give all creatures a +25% chance to reach the first star level, if they are at least 1250m from the center. This value is then modified based on biome settings.
In our example biome file we have a `1.5` value for the distance modifier so `1.5 x 25 = 37.5` would be the increase provided to reach level 1.

If the total bonus and base value exceeds `100` that level will be guaranteed, every creature with that condition will be at a minimum that level.
You can see this in some of the later distance bonuses which slowly drive of the guaranteed spawn level of creatures up

```
  5000:
    1: 100      
    2: 100      # All creatures at least 5000m from center will be level 2+
    3: 75
    4: 50
    5: 25
    6: 15
```

You can also use the distanceLevelBonus to add additional levels, make it so that certain distances are required to spawn higher level enemies.

```
defaultCreatureLevelUpChance:
  1: 20
  2: 15
distanceLevelBonus:
  1250:
    1: 25
    2: 15
    3: 5
  5000:
    1: 100      
    2: 100
    3: 75
    4: 50
```

With the above configuration the region closest to start up to 1250m will only be able to spawn level 1 and 2 creatures. Between 1250m and 5000m creatures can spawn up to level 3, and beyond 5000m creatures can spawn up to level 4.

The Distance Rings page of the quick configure panel (Mod Config button) edits `distanceLevelBonus` without touching YAML:
add and remove rings, move them by typing a new distance, and type each ring's bonus as a list (`25, 15, 5` is levels 1, 2
and 3; a ring that skips a level is shown and typed as `1:25, 3:5`). Beside the list it charts the star chances with no ring
and past the ring you tick, on the curve from the Level Distribution page, weighted by the `All` biome's distance scale.


Now, we've walked through a lot of the bonuses to level up chance but lets take a look at the base values too. 
Star level systems default config has a relatively large spawn range- which is limited by biome configuration.

`defaultCreatureLevelUpChance` Defines the levelup chance of all creatures, this however can be limited by biome configuration and
it can be increased by other factors, such as the distance from center bonus.
```
defaultCreatureLevelUpChance:
  1: 20
  2: 15
  3: 12
  4: 10
  5: 8
  6: 6.5
  7: 5
  8: 3.5
  9: 1.5
  10: 1
  11: 0.5
  12: 0.25
```

#### Level Generators
Writing a long levelup chance table by hand is tedious, so generators build one for you from a level range and a curve style.
A generator can replace the default table (`DefaultLevelupGenerators`), a biome or creature table (`LevelupGenerators`), and is
also used by raid spawns, nemesis spawns and boss-conditional chances. Name a list of generators in `CustomLevelupGenerators` to
reference it from anywhere with `LevelupGeneratorRefs` / `DefaultLevelupGeneratorRefs`.

```
CustomLevelupGenerators:
  late_game:
  - MinLevel: 1
    MaxLevel: 25
    LevelUpChance: 0.35             # 0-1 fraction, 0.35 = 35%
    LevelupCalculationStyle: Gaussian
    GaussianOffset: 0.25            # Gaussian only: -1 to 1, shifts the most likely level
    NightMultiplier: 1.5            # scales these chances at night only, 1.5 = level-ups 50% more likely (1 = no change)
DefaultLevelupGeneratorRefs: [ late_game ]
```

Curve styles:
- `Linear` - the chance to level up drops evenly from `LevelUpChance` at `MinLevel` to nothing at `MaxLevel`.
- `Exponential` - the chance drops quickly at first, so low levels are common and high levels are rare.
- `Gaussian` - a bell curve that favours levels in the middle of the range (moved with `GaussianOffset`).
- `Table` - uses a table you write yourself from `LevelupChanceTablesBySpan` instead of a formula.

Bosses roll from the same chances as everything else unless you give them `BossLevelupGenerators`, which fills
`BossCreatureLevelUpChance` on load and applies to anything the game counts as a boss, modded ones included:

```
BossLevelupGenerators:
- MinLevel: 1
  MaxLevel: 11
  LevelUpChance: 0.3
  LevelupCalculationStyle: Gaussian
```

A boss curve outranks the default, conditional and biome chances wherever that boss stands, while a `CreatureConfiguration`
entry naming the boss still wins over it. `MaxBossLevel` caps bosses either way. The Level Distribution page of the quick
configure panel turns this on and off with its **Own curve for bosses** toggle and charts both curves side by side.

##### Table style
`LevelupChanceTablesBySpan` is keyed by how many levels a generator covers (`MaxLevel - MinLevel + 1`), not by the levels themselves.
Inside a table, key `1` is the generator's `MinLevel`, key `2` is `MinLevel + 1` and so on, so one table can be reused by many generators
that cover the same number of levels at different points in the world. Like `DefaultCreatureLevelUpChance`, each value is the % chance
to roll past that level, so the values must go down. `LevelUpChance` is not used.

```
LevelupChanceTablesBySpan:
  4: { 1: 30, 2: 15, 3: 5, 4: 0.01 }
CustomLevelupGenerators:
  swamp_tier:
  - MinLevel: 3                     # levels 3-6 are 4 levels, so this uses table 4:
    MaxLevel: 6                     # 30% chance to roll past level 3, 15% past 4, 5% past 5
    LevelupCalculationStyle: Table
```

If there is no table for a generator's span it uses the `Exponential` curve instead, and a warning is logged once. Tables that are
missing keys or whose values do not go down are also reported when the config loads. The quick configure panel can edit the table
for its default generator directly: pick the `Table` curve style and type the values separated by commas.

#### Boss-Conditional Levelup Chances
With `EnableConditionalCreatureLevelupChance: true`, each biome's levelup chances change as world bosses are defeated.
`ConditionalCreatureLevelupChance` maps a boss global key to per-biome generators, and `ConditionalBossKeyOrder` decides which boss
counts as furthest along: the latest defeated key in that list that has an entry is used. The order of entries in the file does not matter.

```
EnableConditionalCreatureLevelupChance: true
ConditionalBossKeyOrder:            # earliest to latest; leave out to use this vanilla order
- defeated_eikthyr
- defeated_gdking
- defeated_bonemass
- defeated_dragon
- defeated_goblinking
- defeated_queen
- defeated_fader
ConditionalCreatureLevelupChance:
  defeated_bonemass:
    Meadows:
      LevelupGenerators:
      - { MinLevel: 3, MaxLevel: 16, LevelUpChance: 0.25, LevelupCalculationStyle: Exponential }
```

Add keys from modded bosses where they belong in your progression. An entry whose key is not in the list only applies while no
listed boss has been defeated. The tier changes as soon as a boss key is set or removed, for creatures spawned after that.

The active tier replaces the biome's levelup chances and its level range: creatures there roll between the tier generators'
`MinLevel` and `MaxLevel`, whatever `BiomeMinLevelOverride` / `BiomeMaxLevelOverride` say. An `All` entry inside a tier is the
fallback for biomes the tier does not name. A creature entry with its own curve still wins, and bosses keep `MaxBossLevel`.

### Nemesis System
The Nemesis system is designed to constantly tune the world around a player or group of players to ensure that their experience and challenges are appropriate.

It does this by analyzing things the player does and tracking statistics about the players combat performance. Lower combat scores result in reduced challenge,
high combat scores result in increased challenge.

This is all extremely configurable, and everyone's experience is likely to be very different due to differences in skill or playstyle and that is ok.
Ideally everyone should feel times of challenge, and that setbacks do not feel overwhelmingly punishing.

Nemesis system also contains the ability to make unique enemies that will attempt to hunt you (or a friend) down in the future (small chance to spawn).

Nemesis configuration.
```
NemesisVersion: 1
CreateMinibossFromPlayerKiller: true   # controls whether or not player deaths can result in a nemesis enemy being created
CreationRemovesSourceCreature: true    # whether or not the create that turns into a nemesis boss gets removed from its current location
NemesisBossChance: 0.1                 # chance that a nemesis boss can be created
NemesisBossMaxLevelBonus: 0.4          # percentage level bonus for the nemesis boss
NemesisBossMinLevelBonus: 0.2
NemesisMinionTemplatesByBiome: ...
ScoreSystem:                           # Nemesis score system determines player score and what actions can happen
  NeutralScore: 5000                   # score moves back towards this neutral point all of the time
  MaxScore: 10000                      # max score
  DeathScoreReduction: 1500            # how much score is reduced when the player dies
  DecayPerUpdate: 250                  # how much the score moves towards neutral constantly
  NearbyPlayerRadius: 60               # nearby radius for syncing score with friends
  MeleeDamageDealtFactor: 0.75         # score contribution of melee damage
  MagicDamageDealtFactor: 0.5          # score contribution for magic damage
  RangedDamageDealtFactor: 0.25        # score contribution for ranged damage
  DamageTakenFactor: 0.5               # score lost per point of damage taken (sign is ignored)
  BossKillBonus: 500                   # score bonus from killing a boss
GaurenteedChanges:                     # nemesis changes that always happen
  FirstBossSetLevel: true              # first world boss of each kind when enabled will use the specified level
  FirstBossLevel: 1
```

There are a few additional sections to this config that are worth covering also. Chance changes being the primary one.

```
ChanceChanges:
  CreatureOps:                              # Chance changes are random actions the nemesis system can take
    CharredAttack:                          # name of the action, required unique
      RequiredGlobalKey: defeated_fader     # if the action requires the server has a certain global key
      Chance: 0.3                           # chance the action will happen (valid values 1 <-> 0)
      LevelBonus: 5                         # level bonus applied to spawns from this
      DeniedBiomes:                         # Biomes this is not allowed to happen in
      - DeepNorth
      AllowedBiomes: []                     # Biomes this is allowed to happen in, empty allows all
      ScoreThreshold: 9000                  # Score threshold, the players score must be at least at this level (if above neutral score) or below this level if threshold is below neutral score
      Action: Spawn                         # action, valid options: ChangeLevel, AddModifier, RemoveModifier, Spawn, SpawnMiniboss
      ScoreChange: -2000                    # point change applied to score when this event happens
      SpawnConfig:                          # Spawns associated with this config
      - Prefab: Charred_Melee               # spawn creature prefab
        SpawnGroupSize: 1                   # number of creatures to spawn
        Faction: Boss                       # faction to assign to the creature
        RequiredModifiers:                  # modifiers the creature must have
          Fire: Major
      - Prefab: Charred_Ranged
        SpawnGroupSize: 2
        Faction: Boss
        RequiredModifiers:
          Fire: Major
          ...
```

The final section in this config is NemesisMinionTemplatesByBiome. This controls the minions which can be added to a nemesis spawn.

```
NemesisMinionTemplatesByBiome:
  Meadows:
  - PrefabName: Neck
    MinAmount: 6
    MaxAmount: 9
    CreatureBaseValueModifiers:
      BaseHealth: 2
    CreaturePerLevelValueModifiers:
      DamagePerLevel: 0.01
```


### Colorization (Colorization.yaml)
In vanilla there are few creatures which can be colorized when they level up. Star Level Systems changes that. 
Most all creatures can be colorized, it should be noted that some creatures (Yagluth eg) do not colorize well and the effect is generally not very noticeable.

There are two different ways to apply colorization values to creatures.

- Creature specific color definitions. 
  These are split between default definitions (applied to any creature, if it does not have a more specific entry) 
  and character specific entries. These will be applied at the keyed level to the specified creature.
	```
	  Greydwarf:
		1:
		  hue: -0.06
		  saturation: 0.1
		  value: 0.05
	```
- Color Range definitions. These are ranges of color that will be sliced up and generate gradually changing color patterns 
  based on the ranges between the start and end points.
  ```
  DefaultGenerator:
  - characterSpecific: false
    startColorDef:
      hue: 0.07130837
      saturation: 0.05205864
      value: 0.01721987
    endColorDef:
      hue: -0.07488244
      saturation: 0.09342755
      value: -0.1008582
    rangeStart: 1
    rangeEnd: 15
  ```
  In this example, level ranges for default colors from level 1 to 15 will form a range of colors from hue 0.07130837 -> -0.07488244 etc.
  If you want to see the output from a generator you can enable the debug flag to dump the generated colorization config to a file. 
  You can use this to hand-pick color values etc.

### Loot Configuration
Star level systems provides full optional configuration to control in detail all loot drops. Loot configuration can be found in the `LootSettings.yaml` file.

You may find it useful to see what existing drops look like within the SLS system. 
You can do this by dumping a debug configuration of all loot drops (as they are) with the in-game console command `sls-dump-loottables`, this is output to the SLS config folder in the file `LootTablesDump.yaml`.

There are three core parts to configuring loot drops, but many options to modify if you wish to fine tune loot configurations.

- characterSpecificLoot | this governs all character based loot drops
- nonCharacterSpecificLoot | this controls all non-character based loot drops
- distanceLootModifier | this allows distance scaling of loot, similar to how distance level scaling works

The Loot page of the quick configure panel (Mod Config button) covers how much loot a level is worth without editing YAML:
the loot scaling style (`LootDropCalculationType`), loot and drop chance per star (`PerLevelLootScale`,
`PerLevelLootChanceScale`, `ChanceBaseChancePerLevel`), whether loot that never scales does
(`ScaleAllLootByLevel`), the per-level scales for trees, rocks, destructibles and birds, and the
`distanceLootModifier` rings below, which can be added, removed and moved as well as tuned. Beside them it works those numbers through a real drop table - a Troll's own, read
from the loaded world - at no stars, at your Max stars, and inside the furthest ring, so a slider can be judged by the
loot it produces. Which creatures and objects have a custom table at all still lives in `LootSettings.yaml`.

#### Character Specific Loot configuration
Lets take a look at the character specific loot drop. Here is one of the example configurations, and it is here to address a specific challenge.
Oozers create blobs when they die, this scales with the level of the creature. However, when you have a very high level oozer you can end up with 20,30 or more blobs.
Which can be impossible to deal with. This deals with that in a few ways, the final `- drop:` entry is for the Blob, spawning a minimum of 2 and a maximum of 2. But scaling with
the level of the `BlobElite` (Oozer), however that scaling is capped at a maximum of 6 drops, and only scales `.5` per level. So every other level another blob can be spawned
up to a maximum of 6.

Another useful entry to look at here is the drop for `TrophyBlob`, this has a `0.1` (10%) chance of happening, but it scales x0.01 per level, so a level five is (0.01 x 5) = 0.05 (5%) higher chance of happening.
This can be combined with a drop count to scale the drops for the entry, so a level 5 could drop more trophies. But this is disabled by setting the `maxScaledAmount: 1`
```
characterSpecificLoot:
  BlobElite:
  - drop:
      prefab: Ooze
      min: 2
      max: 3
      levelMultiplier: true
    amountScaleFactor: 0.5
  - drop:
      prefab: IronScrap
      chance: 0.33
      levelMultiplier: true
    amountScaleFactor: 0.2
  - drop:
      prefab: TrophyBlob
      chance: 0.1
      levelMultiplier: true
    chanceScaleFactor: 0.01
    maxScaledAmount: 1
  - drop:
      prefab: Blob
      min: 2
      max: 2
      levelMultiplier: true
    amountScaleFactor: 0.5
    maxScaledAmount: 6
```

#### Non Character specific loot configuration

This is the section which allows you to configure all of the non-creature related loot in detail. It follows a similar structure to character loot configuration.
You can use this to modify or add loot to any existing objects which have the option to drop loot. For example, falling stalactites. This configuration gives them a chance to drop crystals.
The chance scales per level (yes inanimate objects can be leveled, tree, rock or destructible based on type). If loot configuration is not defined here then the generic configuration values from
the main config file apply here `PerLevelDestructibleLootScale`, `PerLevelMineRockLootScale`, and `PerLevelTreeLootScale` along with their max level values.
Level scaling can be ignored by setting `dontScale: true`

```
nonCharacterSpecificLoot:
  caverock_ice_stalagtite_falling:
  - drop:
      prefab: crystal
      chance: 0.3
      min: 1
      max: 3
      dontScale: true
  EvilHeart_Forest:
  - drop:
      prefab: AncientSeed
      onePerPlayer: true
      levelMultiplier: true
    maxScaledAmount: 3
```

#### Distance Loot Modifier
This is similar to the character distance modifier in that it applies a bonus to the minimum and maximum drops that an entry can have based on distance.
Loot rings are not drawn on the map, but behave exactly the same as Character distance rings (if the object is greater than x distance and less than the next once it receives that bonus).

```
distanceLootModifier:
  1250:
    minAmountScaleFactorBonus: 1.02
    maxAmountScaleFactorBonus: 1.02
```

### Raids
SLS supports significantly overhauled and configurable raids. These can be disabled if you wish to revert to vanilla style raids.

By default all raids are per-player, server controlled and concurrent raids are enabled. This means with SLS it is possible that every player on a server gets an appropriate raid
during an event.

The number of players, frequency, and most all details of each raid is configurable through `RaidSettings.yaml`.

The Raids page of the quick configure panel (Mod Config button) covers the common ones without editing YAML: the global
raid settings, which raids are enabled, and per creature in a raid how many arrive each wave (`SpawnGroupSize`), how many
may be alive at once (`MaxSpawned`, where 0 stops that creature spawning) and the seconds between its waves
(`SpawnInterval`). Open a raid's **Spawns** button to see its creatures.

Raid settings are **server authoritative**. On a dedicated or player hosted server the server's `UseVanillaRaidConfiguration` value and its `RaidSettings.yaml` are synced down to every client on join, so editing either of them on a client has no effect - change them on the server.

`RaidSettings.yaml` carries a `RaidVersion` stamp, like `NemesisVersion`. Do not edit it: when the shipped raids change in a way every install should pick up, the version is bumped and a file at any other version (or with none, as every file from before 1.14.0) is reset to the new defaults on load. The previous file is saved next to it first as `RaidSettings.yaml.v<old version>.<date>.bak`, so raids of your own can be copied back in.

#### Raid cooldowns and logging out

Each player's raid cooldown, and the server's own raid check schedule, are saved per world and picked back up exactly where they left off when the world is loaded again. Logging out and back in does not hand anyone a fresh raid.

`RaidCooldownClock` chooses what a cooldown is actually measured against:

- `WorldTime` (default) - the world's own clock. It advances whenever anybody is playing the world, and jumps forward when someone sleeps through a night. On a busy server a player's cooldown keeps burning down while other people play without them.
- `PlayerTime` - each player's own time in the world. A cooldown only counts down while that player is actually online, so logging out with 20 minutes left brings them back with 20 minutes left however long they were away, and other people's sessions do not shorten it.

Neither clock runs while nobody is playing. Switching between them re-bases everyone's remaining cooldown, so nobody gains or loses raid time by the change.

#### Player keys and boss kills

`RequiredGlobalKeys` and `NotRequiredGlobalKeys` check the world's keys, which are the same for everyone. `RequiredPlayerKeys`, `AnyRequiredPlayerKeys` and `NotRequiredPlayerKeys` check each player's own keys, so players can be at different points. The shipped raids only use global keys.

A kill that sets a key (every boss, plus creatures such as the Troll's `KilledTroll`) sets the world key for everyone, but the player key only for whoever gets credit. In vanilla that is the one player whose game controlled the boss; a key share mod such as ValheimCommunityPatch extends it to the players online and nearby. With `GrantWorldDefeatKeysOnJoin` (main config, on by default) SLS catches everyone else up: each time a player joins or respawns, they are given the player key for every defeat the world has already recorded, including kills made while they were offline and keys set with `setkey`. The key is saved on the character like a real kill, so it goes with that character to other worlds.

#### How a raid ends

A raid spawns creatures for its `Duration`. What happens next depends on `RaidActiveTillDefeated`:

- `true` (default) - the raid stays active, with its creatures still hunting and its map pin, music and weather in place, until every creature it spawned is dead. `RaidActiveTillDefeatedMaxSeconds` in the main config (default 300) caps that wait, so a straggler stuck somewhere cannot hold a raid open forever.
- `false` - the raid ends as soon as its `Duration` elapses.

Either way the raid then winds down for `RaidWindDownSeconds`: the end message shows, the pin, music and weather go, and the creatures wander off and despawn. Anything still around at the end of the window is deleted when `RaidForceDeleteStragglers` is on.

While you are inside a raid's area the vanilla event banner at the top of the screen shows the raid's start message, just as it does for vanilla events. `sls-raid-clear-pins` removes every SLS raid pin from your map if any are ever left behind.

Raids never stack. Before a raid starts, the server checks for any raid still in the world within `RaidExclusionRange` (main config, default 500m), running or winding down, whoever it belongs to and however it was started, and skips the new one. The first raid in an area is the only raid; other players elsewhere are still considered. `sls-raid-spawn` is refused the same way.

Below is an example of many of the details that can be configured for a given raid
```
- Name: foresttrolls              # Each raid has its own name, these should be unique or can be incorrectly selected
  Duration: 180                   # Duration of the raid, in seconds
  RaidCoolDownMinutes: 120        # The number of minutes between when this raid triggers and the player becomes eligble for a new raid
  ForceEnvironment: Crypt         # Environment that will be set when the raid starts available options: Clear, Misty, Darklands_dark, DeepForest_Mist, Heath_clear, InfectedMine, GDKing, Rain, LightRain, ThunderStorm, Eikthyr, Fader, 
                                  #  GoblinKing, nofogts, SwampRain, Bonemass, Snow, SnowStorm, Twilight_Clear, Twilight_Snow, Twilight_SnowStorm, Moder, Crypt, CryptHildir, Ghosts, Queen, SunkenCrypt, Mistlands_clear, Mistlands_rain, 
  Activation:                     #  Mistlands_thunder, Ashlands_ashrain, Ashlands_ashrain_clear, Ashlands_CinderRain, Ashlands_meteorshower, Ashlands_misty, Ashlands_SeaStorm, Ashlands_storm, Caves, CavesHildir
    Chance: 50                    # Chance that this raid is selected when it is a valid option, only one raid can be selected for a given player at a time
    RequiredGlobalKeys:           # The global keys required for this raid to activate
    - defeated_eikthyr       
    NotRequiredGlobalKeys:        # The global keys that must be missing for this raid to activate
    - defeated_bonemass
    RequiredPlayerKeys:           # Player keys that must be set to activate
    - Deathlink
    AnyRequiredPlayerKeys:        # Player must have at least ONE of the listed player keys for the raid to be selected for them
    - Deathlink Deathbringer
    - Deathlink Hardcore
    NotRequiredPlayerKeys:        # Player must not have any of the following player keys for the raid to be selected for them
    - Deathlink Vanilla
  Spawns:
  - PrefabName: Troll             # Prefab name of a creature to spawn in the raid
    CreatureAI: AgitatedByBuild   # Type of creature AI setting to apply, valid values are: Alert, AgitatedByBuild, HuntPlayer
    SpawnInterval: 40             # Number of seconds between when another of this monster can spawn
    Faction: Demon                # Faction this creature will be assigned to Valid options: Players, AnimalsVeg, ForestMonsters, Undead, Demon, MountainMonsters, SeaMonsters, PlainsMonsters, Boss, MistlandsMonsters, Dverger, PlayerSpawned
    MaxSpawned: 3                 # Maximum number of this creature that can be alive (from this specific spawn group)
    SpawnGroupSize: 2             # Number of creatures to spawn at once
    LevelMin: 1                   # Min level, if using RaidLevelSystem: rolled levels are raised to at least this
    LevelMax: 3                   # Max level, if using RaidLevelSystem. 0 or left out uses MaxLevel from the main config
    UseRaidLevelSystem: true      # Wether to use the default leveling system or the custom level defintion defined here
    ModifiersNotAllowed:          # Modifiers the creature can't get
    - Poison
    RequiredModifiers:            # Modifiers that the creature must spawn with, this also requires the modifier type (Boss, Major, Minor)
      Fire: Major
    CustomCreatureLevelUpChance:  # Custom level chances for this creature
      1: 50
      2: 25
      3: 20
      4: 15
      5: 7
      6: 3
      7: 1
  StartMessage: $event_foresttrolls_start # Start of the raid message
  EndMessage: $event_foresttrolls_end     # End of the raid message
  ForceMusic: Zblackforest                # Music that starts when the raid happens eg: ZCombatEventL1, ZCombatEventL2, ZCombatEventL3, ZCombatEventL4, Zboss_eikthyr, Zboss_gdking, Zboss_bonemass, Zboss_moder, Zboss_goblinking, Zboss_queen, Zboss_queen_ambience, Zboss_fader, 
                                          #   Zblackforest, Zmeadows, Zswamp, Zmountain, Zplains, Zplainstower, Zmistlands, Zashlands,
```

### Modifiers
Maybe you've tried out CLLC's modifiers, or Monster Modifiers? Both really add variety to the game that is much needed.
Star Levels Systems modifiers are designed to be extremely flexible, both in configuration- but also in effect.

There are however a number of modifiers and it can be a bit unclear what each does. So to start off here is a table of all current modifiers and how they work.

Modifiers are split into three categories. `Boss`, `Major`, and `Minor`. Which allows customization into the random selection process for modifiers, 
along with separate tuning for modifiers that appear on bosses vs minor creatures.

#### Boss Modifiers
These modifiers are by default only available on bosses.

---
|   Modifier   |                                           Description                                          |                                                    Config Adjustment                                                   | Icon |
|:------------:|:----------------------------------------------------------------------------------------------:|:----------------------------------------------------------------------------------------------------------------------:|:----:|
| BossSummoner |              Summons minion creatures at regular intervals up to a certain limit.              | BasePower = Max number summoned PerlevelPower = Time between summon BiomeObjects = Biome specific minion (prefab name) |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/summoner.png?raw=true" width="64" height="64">    |
|   SoulEater  | Creature grows in strength and size when other creatures die near it. Creature heals slightly. |                                    PerlevelPower = how much health & damage to gain                                    |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/vortex.png?raw=true" width="64" height="64">    |
|   LifeLink   |      Creature will redirect a portion of damage it takes to another creature in the area.      |            BasePower = Base damage redirection PerLevelPower = Additional damage redirection based on level            |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/LifeLink2.png?raw=true" width="64" height="64">    |
| ResistPierce | Reduces damage the creatures takes from all pierce sources (like arrows)                       |        BasePower = Base damage reduction PerLevelPower = Additional damage reduction granted per creature level        |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/pierceResist.png?raw=true" width="64" height="64">    |
| Brutal       | Increases creature attack speed                                                                |      BasePower = Increases attack speed by base amount PerLevelPower = Increases attack speed by amount per level      |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/brutal.png?raw=true" width="64" height="64">    |


#### Major Modifiers
These modifiers are attainable by most creatures, and are typically the more impactful modifiers.

---
|   Modifier       |                Description                |                                                                                                     Config Adjustment                                                                                                     | Icon |
|:----------------:|:-----------------------------------------:|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------:|:----:|
|    Brutal        |      Increases creature attack speed      |                                                                   BasePower = Increases attack speed PerLevelIncrease = Increases attack speed per level                                                                  |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/brutal.png?raw=true" width="64" height="64">     |
|     Fire         |              Adds Fire damage             |                                                             BasePower = Percentage of total damage added PerLevelIncrease = Additional damage added per level                                                             |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/flame.png?raw=true" width="64" height="64">     |
|     Frost        |             Adds Frost Damage             |                                                             BasePower = Percentage of total damage added PerLevelIncrease = Additional damage added per level                                                             |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/snowflake.png?raw=true" width="64" height="64">     |
|    Poison        |             Adds Poison Damage            |                                                             BasePower = Percentage of total damage added PerLevelIncrease = Additional damage added per level                                                             |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/poison.png?raw=true" width="64" height="64">     |
|   Lightning      |           Adds Lightning damage           |                                                             BasePower = Percentage of total damage added PerLevelIncrease = Additional damage added per level                                                             |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/lightning.png?raw=true" width="64" height="64">     |
| Elemental Chaos  | Random typed elemental damage on each hit |                                                             BasePower = Percentage of total damage added PerLevelIncrease = Additional damage added per level                                                             |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/eleChaos.png?raw=true" width="64" height="64">     |
|   Splitter       | Creature spawns replacements when it dies | Config values are combined and for each whole value, an additional creature is spawned BasePower = Number of creatures to spawn on replacement PerLevelIncrease = Additional value added to give a chance for more spawns |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/Splitting.png?raw=true" width="64" height="64">     |
| ResistPierce     |      Reduces damage taken from Pierce     |                                                                 BasePower = base damage reduction PerLevelIncrease = per level additional damage reduction                                                                |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/pierceResist.png?raw=true" width="64" height="64">     |
|  ResistSlash     |      Reduces damage taken from Slash      |                                                                 BasePower = base damage reduction PerLevelIncrease = per level additional damage reduction                                                                |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/slashResist.png?raw=true" width="64" height="64">     |
|  ResistBlunt     |      Reduces damage taken from Blunt      |                                                                 BasePower = base damage reduction PerLevelIncrease = per level additional damage reduction                                                                |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/bluntResist.png?raw=true" width="64" height="64">     |


#### Minor Modifiers
These modifiers are attainable by most creatures and are typically less directly impactful than others, but can be none the less dangerous.

---
|   Modifier   |                                 Description                                 |                                                     Config Adjustment                                                     | Icon |
|:------------:|:---------------------------------------------------------------------------:|:-------------------------------------------------------------------------------------------------------------------------:|:----:|
|   FireNova   |                 Explodes when it dies, damaging everything.                 | BasePower = Base damage of the explosion, based on creature damage PerLevelPower = Increase to the damage added per level |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/fireNova.png?raw=true" width="64" height="64">   |
| PoisonNova   |                 Explodes when it dies, damaging everything.                 | BasePower = Base damage of the explosion, based on creature damage PerLevelPower = Increase to the damage added per level |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/poisonNova.png?raw=true" width="64" height="64">   |
|   Lootbags   | Doubles creature health and gives 25% more movement speed, drops more loot. |                      BasePower = Increases drops PerLevelPower = Increases drops by amount per level                      |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/lootbag.png?raw=true" width="64" height="64">   |
|     Alert    |                       Increases creature hearing range                      |                   BasePower = Increase hearing by PerLevelPower = Increase hearing by amount each level                   |      |
|      Big     |                      Increases creature size and health                     |                 BasePower = Increases health and size PerLevelPower = Increases health and size by amount                 |      |
|     Fast     |                           Increases creature speed                          |                    BasePower = Increases movement speed PerLevelPower = Increases speed based per level                   |      |
|   Evolving   | After X kills the creature gains a level                                    | BasePower = Base number of kills required PerLevelIncrease = Additional kills required per level                          |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/evolve.png?raw=true" width="64" height="64">     |
| StaminaDrain |                  Attacks by the creature drain your stamina                 |                        BasePower = Drain amount PerLevelPower = Drain increase by amount per level                        | <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/staminaDrain.png?raw=true" width="64" height="64">   |
|   EitrDrain  |                   Attacks by the creature drain your Eitr                   |                        BasePower = Drain amount PerLevelPower = Drain increase by amount per level                        | <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/eitrEater.png?raw=true" width="64" height="64">   |
|  ResistFire  |      Reduces damage taken from Fire                                         |                        BasePower = base damage reduction PerLevelIncrease = per level additional damage reduction         |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/FireRes.png?raw=true" width="64" height="64">     |
|  ResistFrost |      Reduces damage taken from Frost                                        |                        BasePower = base damage reduction PerLevelIncrease = per level additional damage reduction         |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/FrostRes.png?raw=true" width="64" height="64">     |
|  ResistPoison|      Reduces damage taken from Poison                                       |                        BasePower = base damage reduction PerLevelIncrease = per level additional damage reduction         |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/PoisonRes.png?raw=true" width="64" height="64">     |
|  ResistSpirit|      Reduces damage taken from Spirit                                       |                        BasePower = base damage reduction PerLevelIncrease = per level additional damage reduction         |  <img src="https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/blob/master/StarLevelUnity/Assets/Custom/StarLevels/Icons2/SpiritRes.png?raw=true" width="64" height="64">     |

### Location Reset (LocationResetSettings.yaml)
> **Back up your world before enabling this.** Location Reset destroys and recreates world objects.

On a busy server the world is a finite pool of loot. Crypts, camps, ore and pickables get consumed
once and never come back, so late joiners and less-active players are permanently locked out of
content the early players already stripped. Location Reset brings that content back on a timer.

**It is disabled by default, and every location and vegetation entry is opt-in.** Turn on
`EnableLocationReset`, then set `Enabled: true` on the specific things you want to come back.

The Location Reset page of the quick configure panel (Mod Config button) covers the common settings
without editing YAML: one switch for both master switches, the default timer and terrain reset, the
safe and protection radii, chest refills, the sweep budget, biome rates, and each reset group's on/off,
timer and terrain reset. Group members, schedules, distance limits and protection rules stay in the file.

How it works:
- **Resets happen in the background, only in zones with no players nearby.** Nobody ever watches a
  location pop out and back in, which is what causes the lag spikes and item duplication other
  reset mods warn about. A chunk somebody happened to be standing in is re-tried a couple of times
  a few minutes later rather than losing its whole cycle.
- **Locations are restored, not re-rolled.** The original position and rotation are kept, so
  buildings never rotate, shift or clip into the terrain after a reset.
- **Ore, pickables and vegetation come back in exactly their original spots**, because placement is
  replayed using the world's own generation seed. Replaying it re-places every node in the chunk, so
  the ones still standing are matched by position and discarded rather than stacked on top of the
  survivor — `sls-loc-audit` will tell you if any ever slip through.
- **Dungeon interiors reset with their entrance** — crypts, caves, mines and citadels.
- **Terrain can be reset** around ore to undo mining craters. Locations also support
  `Mode: TerrainOnly`, which flattens the ground around one without touching the structure itself.
- **Your stuff is safe.** Player-built structures, tombstones, wards, portals, beds, player-placed
  chests, tamed creatures and any chunk inside a player's base all block a reset. Protection is
  configurable per entry, so you can decide (for example) that a stray dropped item is preserved
  rather than blocking the whole zone.
- `StartTemple` can never be reset. Boss altars are covered by the `BossAltars` group, which ships
  enabled with terrain reset on to undo the crater players dig around a summoning circle — set
  `Enabled: false` on that group to leave them alone.

Timers are in **real-world hours** (`ResetHours`), which stays predictable on a server that runs
24/7. Throughput is controlled by `LocationResetSweepBudgetMs` — the milliseconds of server frame
time the sweep may use per frame. Raise it to restore the world faster; it automatically backs off
when the server is under load. Use `sls-loc-status` to see the projected time for a full pass.

**An already-explored world baselines itself.** The first time resets are switched on in a world
with no reset timers of its own, every generated zone is stamped as reset right then, so timers
start from that moment instead of everything becoming due at once. The same happens if the state
file is ever lost. Set `StampOnFirstSight: false` to skip it and have the sweep reset an explored
world instead; `sls-loc-stamp` re-baselines a world by hand at any time.

**Reset groups.** Groups are how this feature is configured. A group configures and **enables** a
whole set of targets in one block, and stands on its own — a member needs no entry anywhere else in
the file:

```yaml
ResetGroups:
  Ores:
    Enabled: true
    ResetHours: 48
    ResetTerrain: true
    Members: [rock4_copper, MineRock_Tin, silvervein, rock3_silver, mudpile_beacon]
```

To turn a whole category off, set its `Enabled: false`; to drop one target, remove it from
`Members`. If two groups claim the same prefab the shorter interval wins and the other is named in a
warning, and a member name your game version has nothing for is warned about at load.

A member can also be a category token — `$Mineable` or `$Pickable` — which expands to everything the
world *places* carrying that component, and so picks up modded ore and pickables automatically.
Unlike a named member a token stops there: one-off pickups that only exist inside dungeons are not
swept up by it, so name those explicitly if you want them. Note that berry bushes are *not*
`Pickable_*` prefabs, which is why the shipped config lists them separately. Prefab names are
irregular enough that this matters: copper is `rock4_copper` while `rock4_forest` is worthless
scenery, and silver is both `rock3_silver` and `silvervein`.

A group can be limited to a ring around spawn with `MinDistance` / `MaxDistance` (`MaxDistance: 0`
means no outer limit). A scoped group applies only inside its range; outside it, its members fall
back to whatever unscoped group covers them — so `FlintNearSpawn` at 6h within 3000m leaves flint on
the normal foraging timer everywhere else.

The mod ships working groups (`BossAltars`, `Ores`, `Berries`, `Foraging`, `FlintNearSpawn`,
`Leviathans`, `QuestSites`, `CharredSpawners`, `AshlandsForts`) **already enabled**, so the feature
is usable without editing anything. Nothing resets until `EnableLocationReset` and the YAML
`Enabled` are both turned on. `sls-loc-status` lists every group with a `matched/total` member
count — a shortfall means a prefab name no longer exists in your game version.

**Locations and Vegetation are overrides.** Both ship empty and can usually stay that way. Add a key
only to retune one target or to enable something no group covers; values resolve as
**entry → group → Defaults**, so a per-prefab setting always beats its group:

```yaml
Locations:
  Eikthyrnir:
    ResetHours: 12        # BossAltars still enables it; this just retimes it
```

For the full list of names your world can reset — including everything other mods add — run
`sls-loc-dump`. It writes `SavedData/LocationResetCatalog.yaml` as a reference; that file is a
dump, not a config, and editing it does nothing.

**Advanced sections are omitted while unused.** `Throughput`, `InPlaceRefresh`, `ProtectedPrefabs`
and `DistanceBands` are left out of the generated file because their defaults suit almost every
server. Add a section by hand to use one — anything you leave out keeps its default. The config
file's own header comment documents each with its default value.

**Scheduling by clock time.** `ResetHours` measures elapsed time since a target last reset, so a
24h timer drifts a little later every cycle and you cannot say "restock overnight". `ResetSchedule`
takes a cron expression instead, usable anywhere `ResetHours` is:

```yaml
ResetGroups:
  Ores:
    ResetSchedule: 0 3 * * *        # 03:00 every day
  Foraging:
    ResetSchedule: '*/30 * * * *'   # every 30 minutes
  AshlandsForts:
    ResetSchedule: 0 4 * * MON      # 04:00 on Mondays
```

Fields are `minute hour day-of-month month day-of-week`, supporting `*`, `,`, `-` and `*/n`.
Day-of-week is `0-6` (0 = Sunday) or `SUN`–`SAT`, months are `1-12` or `JAN`–`DEC`, and the macros
`@hourly`, `@daily`, `@midnight`, `@weekly`, `@monthly` and `@yearly` all work. Quote any expression
starting with `*`, or YAML will read it as an alias.

Times are the **server's local time**, not UTC and not in-game time. Two things to know:

- If **both** day-of-month and day-of-week are restricted, a day matching *either* fires —
  `0 0 1 * MON` is the 1st of the month **and** every Monday. Surprising, but it is what every cron
  does.
- `BiomeRates` and `DistanceBands` do **not** scale a cron schedule; there is no sensible way to
  halve "every Tuesday at 3am". A rate of `0` still excludes the chunk entirely.

The two fields resolve as one unit, entry → group → Defaults: the first level that sets *either* one
owns the timing, so a per-prefab `ResetHours` still overrides its group's `ResetSchedule`. An invalid
expression is logged and that target quietly falls back to `ResetHours` rather than taking the config
file down.

**Focusing resets where they are needed.** Depletion is not uniform — it concentrates in the
biomes and near the spawn areas your players actually work. Two multipliers stack on top of each
entry's own `ResetHours`, so `effective hours = ResetHours × biome rate × band rate`, and both
default to `1.0`:

```yaml
BiomeRates:
  Meadows: 0.5          # everything in the Meadows returns twice as fast
  Mistlands: 2.0        # ...and half as fast out in the Mistlands
DistanceBands:
- Inner: 0              # metres from spawn
  Outer: 3000
  Multiplier: 0.5       # the hub recovers twice as fast
```

A rate of `0` **excludes** that biome or band from resets entirely — it does not mean "instantly" —
which is also the cheap way to say "only reset near spawn". `Outer: 0` means no outer limit, and a
chunk matching no band is left at `1.0`, so a partial band list never disables the rest of the
world. Distance is measured from the same point as the distance level-scaling rings; see
`DistanceBonusIsFromStarterTemple`.

**Ignoring trivial player clutter.** One abandoned campfire otherwise freezes a chunk forever: any
player-built piece blocks a reset, and the protection scan covers a chunk *and its 8 neighbours*.
Worse, a campfire sitting on an ore spawn stops that node coming back even when the chunk does
reset, because vanilla will not place vegetation into a collider. Each protection category can list
prefabs exempt from it:

```yaml
Protection:
  PlayerBuiltPiece:
    Action: Block
    Ignored:
    - fire_pit
```

> An ignored prefab neither blocks a reset **nor survives one — it is deleted.** `fire_pit` ships
> ignored for the reasons above; add to the list sparingly. Tombstones can never be ignored, and
> anything in `ProtectedPrefabs` wins over an ignore. Every deletion is recorded in the chunk log.

**Player bases.** A chunk is also left alone while any part of it lies inside a player's base — the
area around a workbench and similar pieces that stops monsters spawning in vanilla. This is the
`PlayerBaseEffect` category, and it reaches exactly as far as that area does rather than
`ProtectionRadius`. A prefab ignored under `PlayerBuiltPiece` does not count as a base either, so the
shipped `fire_pit` ignore covers both. A reset group can relax it like any other category:

```yaml
ResetGroups:
  Ores:
    Protection:
      PlayerBuiltPiece: Ignore   # stray builds no longer hold ore chunks...
      PlayerBaseEffect: Ignore   # ...and neither does a workbench abandoned on an ore spawn
```

**Resetting terrain around a location.** Players dig approach ramps and moats just *outside* a
dungeon's footprint, where the normal terrain reset does not reach. `ExtraTerrainRadius` on a
location entry adds metres beyond the location's own radius, clamped to `ProtectionRadius` minus
32m — 16m at the default, 64m at most — which is as far as the protection scan actually checks for
player property:

```yaml
Locations:
  Crypt2:
    Enabled: true
    ResetTerrain: true
    ExtraTerrainRadius: 16
```

**Seeing what it did.** Every chunk the system works on gets a record in
`SavedData/LocationResetLog.log` — its zone coordinates, world position and biome, and what was and
was not reset inside it, including the reason anything was skipped:

```
Zone -12,34 @ x=-768 z=2176 (BlackForest) reset: refreshed pickables 14, minerock 3 | location 'Crypt2' rebuilt (cleared 214, spawned 218) | ZDO 402->405
Zone -12,35 @ x=-768 z=2240 (Meadows) skipped: protected by PlayerBuiltPiece 'wood_floor' at x=-742 z=2251
Zone -12,36 @ x=-768 z=2304 (Meadows) nothing reset: location 'FireHole' not due, 3 vegetation entries not due
```

Turn this off with `EnableLocationResetLog`. `EnableDebugLocationResetDetails` additionally copies
the background sweep's chunk lines into the BepInEx log and expands every record with a per-entry
breakdown of what was skipped and why. Both are client-side settings, so on a dedicated server they
are configured on the server itself.

Not compatible with VentureValheim's LocationReset — SLS disables its own Location Reset
automatically if that mod is present, since both would fight over the same objects.

### Localization
Localization is available for everything in the mod. I accept community translations! If you would like to contribute localizations or improve them please reach out on discord.

Otherwise localizations are available at `Bepinex/config/StarLevelSystems/localizations`, new languages can be made using any of [Jotunns language specific names](https://valheim-modding.github.io/Jotunn/data/localization/language-list.html)

### Terminal Commands
Star Level Systems provides a number of terminal commands for debugging, testing and cleanup. Type
`sls-help` in the console for the full list, or `sls-help loc` for a single group. Tab-completes each
argument as you type it, and colours output by severity (turn that off with the `EnableTerminalColors`
client setting if you prefer plain text).

- `sls-help [area]` - lists the StarLevelSystem commands, optionally just one area
- `sls-creature-killall [range:500]` - kills creatures within the specified range (default 500m), skips players and tamed creatures
- `sls-creature-setlevel [level] [range:64]` - sets the closest creature (within the search range) to the given level. Level 1 is no stars, 2 is one star, and so on; clamped to that creature's configured maximum
- `sls-mod-give [modifier_type:major] [modifier_name:fire]` - gives nearby creatures the specified modifier (must be very close)
- `sls-loot-dump` - dumps all loot table configurations in the game, in SLS format, to `Bepinex/config/StarLevelSystems/LootTablesDump.yaml`
- `sls-zone-rebuild` - regenerates the zone map from the world and redraws the minimap overlay. Resets zone kill counts and levels
- `sls-nemesis-spawn [biome]` - force-scouts and places one remote Nemesis boss
- `sls-nemesis-score [value]` - sets your local Nemesis score
- `sls-raid-spawn [raid_name] [x] [z]` - force-starts a raid, ignoring every cooldown and activation requirement (biome, keys, player base), but not a raid already running within `RaidExclusionRange`. Tab-completes the raid names from your `RaidSettings.yaml`. Defaults to your own position; pass an `x` and `z` to start it somewhere else. The raid does not consume the target player's raid cooldown, so it will not delay their next natural raid. Works on raids that are disabled or while `DisableAllRaids` is set, so you can test one before turning it on
- `sls-raid-clear-pins` - removes every SLS raid map pin (the red event circle and the `!` marker) from your own map. Raids still running near you redraw theirs; pins left behind by a raid that has ended are gone for good. Pins are local to each client, so no admin is needed

Location Reset commands (server authoritative):
- `sls-loc-status` - reports sweep throughput, how much of the world has been examined, the projected time for a full pass, and cumulative ZDO drift
- `sls-loc-dump` - writes every location and vegetation entry this world knows about (including ones other mods add) to `SavedData/LocationResetCatalog.yaml`, for use when configuring `LocationResetSettings.yaml`
- `sls-loc-stamp` - stamps every generated zone as reset right now, restarting every timer from today. A world with no timers at all does this automatically when resets are switched on, so this is for re-baselining one that already has them
- `sls-loc-reset [range:64]` - immediately resets the chunks around you, ignoring every timer, including the chunks currently loaded around you. Reports each chunk it touched to the console. Player structures are still protected
- `sls-loc-audit [range:256] [fix]` - scans for duplicate world objects and surplus terrain compilers. Reports only unless `fix` is passed

#### Running the server commands from a client

The Location Reset commands, `sls-nemesis-spawn` and `sls-raid-spawn` act on world state only the server owns. A
dedicated server has no console of its own, so an **admin** can now run them from a connected client:
the request goes to the server, the server runs it, and its output is streamed back into your console
as well as being written to the server's log. `sls-loc-reset` and `sls-loc-audit` centre on **your**
position, which is what makes them usable on a headless server at all.

Non-admins are refused. Several of these are flagged as cheat commands, which vanilla only allows once
`devcommands` is active — on a server that requires
[Server devcommands](https://github.com/JereKuusela/valheim-dev) on the client. `sls-loc-status` is not
a cheat command and works without it.

#### Renamed commands

Commands were regrouped as `sls-<area>-<verb>` in 1.5.2. Every old name still works and is accepted
silently, so existing macros and guides are unaffected; `sls-help` lists the old name alongside each
command.

| Old name | New name |
| --- | --- |
| `SLS-killall` | `sls-creature-killall` |
| `SLS-give-modifier` | `sls-mod-give` |
| `SLS-Dump-LootTables` | `sls-loot-dump` |
| `SLS-rebuild-zones` | `sls-zone-rebuild` |
| `SLS-spawn-nemesis-remote` | `sls-nemesis-spawn` |
| `SLS-SetNem-Score` | `sls-nemesis-score` |
| `SLS-reset-player-modifiers` | `sls-player-reset` |
| `sls-loc-status` | `sls-loc-status` |
| `sls-loc-reset` | `sls-loc-reset` |
| `sls-loc-audit` | `sls-loc-audit` |
| `sls-loc-dump` | `sls-loc-dump` |
| `sls-loc-stamp` | `sls-loc-stamp` |

### API Usage (WIP)
Star Level Systems provides a public API for other mods to interact with.
The API currently allows reading, modifying and managing creature stat modifiers, color, and level.
Check out the API Documentation [here](https://github.com/MidnightsFX/Valheim_Star_Levels_Expanded/tree/master/StarLevelSystem/API)


## Some of my other mods
- [Valheim Armory](https://thunderstore.io/c/valheim/p/MidnightMods/ValheimArmory/) - Fill in vanilla weapon gaps with fitting weapons
- [Impactful Skills](https://thunderstore.io/c/valheim/p/MidnightMods/ImpactfulSkills/) - Make your skills meaningful
- [Deathlink](https://thunderstore.io/c/valheim/p/MidnightMods/Deathlink/) - Death choices for all your players with progression
- [InfiniteFire](https://thunderstore.io/c/valheim/p/MidnightMods/ValheimInfiniteFire/) - Torches/Fires configurable don't require fuel
- [Valheim Fortress](https://thunderstore.io/c/valheim/p/MidnightMods/ValheimFortress/) - Build a base, defend it, reap the rewards!
- [Recipe Manager](https://thunderstore.io/c/valheim/p/MidnightMods/RecipeManager/) - Configure Recipes, build pieces, and conversions
- [Epic Jewels](https://thunderstore.io/c/valheim/p/MidnightMods/EpicJewels/) - More Jewelcrafting gem options

I also directly contribute to Epic Loot! If you like new features and bugfixes always happy to hear feedback.

## Installation (manual)
Modded Valheim requires Bepinex to load mods. If you have not modded before or are trying to simplify how easy it is for you to mod the game I recommend taking a look at a mod manager.
[Gale](https://thunderstore.io/c/valheim/p/Kesomannen/GaleModManager/) is an excellent mod manager. Download it manually, install and start it up.

If you are proceeding manually you will need to ensure that you have installed [Bepinex from the Thunderstore](https://thunderstore.io/c/valheim/p/denikson/BepInExPack_Valheim/), it has required configuration.

Once you are ready to install mods, they must be unzipped first and go into the `Bepinex/plugins` folder.

- Download and install [Yaml.net](https://thunderstore.io/c/valheim/p/ValheimModding/YamlDotNet/) and [Jotunn](https://thunderstore.io/c/valheim/p/ValheimModding/Jotunn/)
- Download this mod and install it!

## Compatibility
- This mod is incompatible with Creature Level and Loot Control (they do the same things)
- SLS Location Reset is automatically disabled if VentureValheim's LocationReset is installed, since both reset the same objects on their own timers. The rest of Star Level System works normally
- Upgrade World can be used alongside SLS, but avoid running its `locations_reset` / `vegetation_reset` commands against zones SLS Location Reset manages

Compatibility is being worked on for the following mods:
- CarryMeMaster
- PortablePals

## Contributions
If you would like to donate, any amount is appreciated!
- Donators can have a name of their choice added to the Nemesis system (must be approved).

I welcome pull requests, fixes, and improvements.

## Planned Features
This mod is still in active development and is not considered complete yet.

Planned Features
- Refinement to the existing modifiers
- New modifiers!
- Generic and biome specific loot multipliers